script.statistics.gsoc2012.scraper
==================================

Statistics gather addon for XBMC GSoC 2012


Fanart taken from: http://www.flickr.com/photos/teegardin/5537894072/in/photostream
Icon taken from: http://www.flickr.com/photos/arenamontanus/5657887546/
