'''
    letmewatchthis XBMC Addon
    Copyright (C) 2011 t0mm0

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import string
import sys
from t0mm0.common.addon import Addon
import urllib2
import urllib
import urlresolver
import xbmcgui
import xbmcplugin
import xbmc, xbmcvfs 

ADDON = Addon('plugin.video.1channel', sys.argv)

#Disabled due to atv2/ipad storage server problem
# try: 
	# import StorageServer
	# print 'Storage imported succesfully'
# except: 
	# import storageserverdummy as StorageServer
	# print 'Falling back to storageserverdummy'
# cache = StorageServer.StorageServer()
# cache.table_name = 'onechannel' #ADDON.get_name()
# dbg = True #Enable storage common cache debugging

try:
	from sqlite3 import dbapi2 as sqlite
	print "Loading sqlite3 as DB engine"
except:
	from pysqlite2 import dbapi2 as sqlite
	print "Loading pysqlite2 as DB engine"

DB = os.path.join(xbmc.translatePath("special://database"), 'onechannelcache.db')
AZ_DIRECTORIES = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z']
BASE_URL = 'http://www.1channel.ch'
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
GENRES = ['Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 
          'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Game-Show', 
          'History', 'Horror', 'Japanese', 'Korean', 'Music', 'Musical', 
          'Mystery', 'Reality-TV', 'Romance', 'Sci-Fi', 'Short', 'Sport', 
          'Talk-Show', 'Thriller', 'War', 'Western', 'Zombies']

def AddOption(text, isFolder, mode, letter=None, section=None, sort=None, genre=None, query=None, page=None):
	li = xbmcgui.ListItem(text)
	print 'Adding option with params:\n Text: %s\n Folder: %s\n Mode %s\n Letter: %s\n Section: %s\n Sort: %s\n Genre: %s' %(text, isFolder,mode, letter, section, sort, genre)
	url = sys.argv[0]+'?mode=' + str(mode)
	if letter  is not None: url += '&letter=%s'  % letter
	if section is not None: url += '&section=%s' % section
	if sort    is not None: url += '&sort=%s'	 % sort
	if genre   is not None: url += '&genre=%s'	 % genre
	if query   is not None: url += '&query=%s'	 % query
	if page    is not None: url += '&page=%s'	 % page
	
	return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)

def unicode_urlencode(value): 
	if isinstance(value, unicode): 
		return urllib.quote_plus(value.encode("utf-8")) 
	else: 
		return urllib.quote_plus(value) 

def initDatabase():
	print "Building 1channel Database"
	if ( not os.path.isdir( os.path.dirname( DB ) ) ):
		os.makedirs( os.path.dirname( DB ) )
	db = sqlite.connect( DB )
	cursor = db.cursor()
	cursor.execute('CREATE TABLE IF NOT EXISTS seasons (season UNIQUE, contents);')
	cursor.execute('CREATE TABLE IF NOT EXISTS favorites (type, name, url, img);')
	db.commit()
	db.close()

def GetURL(url, params = None, referrer = BASE_URL, cookie = None, save_cookie = False, silent = False):
	if params: req = urllib2.Request(url, params)
		# req.add_header('Content-type', 'application/x-www-form-urlencoded')
	else: req = urllib2.Request(url)

	req.add_header('User-Agent', USER_AGENT)
	req.add_header('Host', 'www.1channel.ch')
	if referrer: req.add_header('Referer', referrer)
	if cookie: req.add_header('Cookie', cookie)

	print 'Fetching URL: %s' % url
	
	try:
		response = urllib2.urlopen(req)
		body = response.read()
	except:
		if not silent:
			dialog = xbmcgui.Dialog()
			dialog.ok("Connection failed", "Failed to connect to url", url)
			print "Failed to connect to URL %s" % url
			return ''

	if save_cookie:
		setcookie = response.info().get('Set-Cookie', None)
		#print "Set-Cookie: %s" % repr(setcookie)
		if setcookie:
			setcookie = re.search('([^=]+=[^=;]+)', setcookie).group(1)
			body = body + '<cookie>' + setcookie + '</cookie>'

	response.close()
	return body

def GetSources(url, title='', img=''): #10
	url	  = urllib.unquote_plus(url)
	title = urllib.unquote_plus(title)
	print 'Playing: %s' % url
	html = GetURL(url)

	#find all sources and their info
	sources = []
	for s in re.finditer('class="movie_version.+?quality_(?!sponsored)(.+?)>.+?url=(.+?)' + 
						 '&domain=(.+?)&.+?"version_veiws">(.+?)</', 
						 html, re.DOTALL):
		q, url, host, views = s.groups()
		verified = s.group(0).find('star.gif') > -1
		label = '[%s]  ' % q.upper()
		label += host.decode('base-64')
		if verified: label += ' [verified]'
		label += ' (%s)' % views.strip()
		url = url.decode('base-64')
		host = host.decode('base-64')
		print 'Source found:\n quality %s\n url %s\n host %s\n views %s\n' % (q, url, host, views)
		try:
			hosted_media = urlresolver.HostedMediaFile(url=url, title=label)
			sources.append(hosted_media)
		except:
			print 'Error while trying to determine'

	source = urlresolver.choose_source(sources)
	if source: stream_url = source.resolve()
	else: stream_url = ''
	listitem = xbmcgui.ListItem(title, iconImage=img, thumbnailImage=img)
	xbmc.Player().play(stream_url, listitem)

def GetSearchQuery(section):
	if section == 'tv': heading = 'Search TV Shows'
	else: heading = 'Search Movies'
	keyboard = xbmc.Keyboard(heading=heading)
	keyboard.doModal()
	if (keyboard.isConfirmed()):
		Search(section, keyboard.getText())
	else:
		BrowseListMenu(section)

def Search(section, query):
	#TODO: Combine this with GetFilteredResults
	html = GetURL(BASE_URL)
	r = re.search('input type="hidden" name="key" value="([0-9a-f]*)"', html).group(1)
	pageurl = BASE_URL + '/index.php?search_keywords='
	pageurl += urllib.quote_plus(query)
	pageurl += '&key=' + r
	if section == 'tv': pageurl += '&search_section=2'
	html = '> >> <'
	page = 0

	if section == 'tv': nextmode = '?mode=4000'
	else: nextmode = '?mode=10'

	while html.find('> >> <') > -1 and page < 10:
		page += 1
		if page > 1: pageurl += '&page=%s' % page
		html = GetURL(pageurl)
		print 'Pageurl during loop: %s' % pageurl

		#if html: print 'XXXXXXXXXXXXX HTML IS: %s' % html
		r = re.search('number_movies_result">([0-9,]+)', html)
		if r: total = int(r.group(1).replace(',', ''))
		else: total = 0
		#print 'XXXXXXXXXXXXX TOTAL IS: %s' % total

		r = 'class="index_item.+?href="(.+?)".+?src="(.+?)".+?' + \
			'alt="Watch (.+?)"'
		regex = re.finditer(r, html, re.DOTALL)
		resurls = []
		for s in regex:
			resurl, thumb, title = s.groups()
			if resurl not in resurls:
				resurls.append(resurl)
				#title = ADDON.unescape(title)
				listitem = xbmcgui.ListItem(title, iconImage=thumb, thumbnailImage=thumb)
				title = unicode_urlencode(title)
				resurl = BASE_URL + resurl
				liurl = sys.argv[0] + nextmode
				liurl += '&title=' + title
				liurl += '&img='	 + thumb
				liurl += '&url=' + resurl
				xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=liurl, listitem=listitem, 
							isFolder=True, totalItems=total)

	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def AddonMenu():  #homescreen
	print '1Channel menu'
	AddOption('Movies',  True, 500, section=None)
	AddOption('TV shows',True, 500, section='tv')
	AddOption('Settings',True, 9999)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def BrowseListMenu(section=None): #500
	AddOption('A-Z',		  True, 1000, section=section)
	AddOption('Search',		  True, 6000, section=section, query=query)
	AddOption('Genres',		  True, 2000, section=section)
	AddOption('Featured', 	  True, 3000, section=section, sort='featured')
	AddOption('Most Popular', True, 3000, section=section, sort='views')	
	AddOption('Highly rated', True, 3000, section=section, sort='ratings')
	AddOption('Date released',True, 3000, section=section, sort='release')	
	AddOption('Date added',	  True, 3000, section=section, sort='date')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def BrowseAlphabetMenu(section=None, genre=None): #1000
	print 'Browse by alphabet screen'
	AddOption('#123',True,3000,letter='123', section=section, genre=genre, sort='alphabet')
	for character in AZ_DIRECTORIES:
		AddOption(character,True,3000,letter=character, section=section, genre=genre, sort='alphabet')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def BrowseByGenreMenu(section=None, letter=None): #2000
	print 'Browse by genres screen'
	for g in GENRES:
		AddOption(g,True,1000,genre=g,section=section,letter=letter)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetFilteredResults(section=None, genre=None, letter=None, sort='alphabet', page=None): #3000
	print 'Filtered results for Section: %s Genre: %s Letter: %s Sort: %s Page: %s' % \
			(section, genre, letter, sort, page)
	if section == 'tv':	xbmcplugin.setContent( int( sys.argv[1] ), 'tvshows' )
	else: xbmcplugin.setContent( int( sys.argv[1] ), 'movies' )

	liurl = BASE_URL + '/?'
	if section == 'tv': liurl += 'tv'
	if genre  is not None:	liurl += '&genre='  + genre
	if letter is not None:	liurl += '&letter=' + letter
	if sort   is not None:	liurl += '&sort='	+ sort
	pageurl = liurl
	if page: pageurl += '&page=%s' % page

	if section == 'tv': nextmode = '?mode=4000'
	else: nextmode = '?mode=10'

	html = GetURL(pageurl)

	r = re.search('number_movies_result">([0-9,]+)', html)
	if r: total = int(r.group(1).replace(',', ''))
	else: total = 0

	r = 'class="index_item.+?href="(.+?)" title="Watch (.+?)">.+?src="(.+?)"'
	regex = re.finditer(r, html, re.DOTALL)
	resurls = []
	for s in regex:
		resurl, title,thumb = s.groups()
		if resurl not in resurls:
			resurls.append(resurl)
			#title = ADDON.unescape(title)
			listitem = xbmcgui.ListItem(title, iconImage=thumb, thumbnailImage=thumb)
			title = unicode_urlencode(title)
			resurl = BASE_URL + resurl
			liurl = sys.argv[0] + nextmode
			liurl += '&title=' + title
			liurl += '&img='	 + thumb
			liurl += '&url=' + resurl
			xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=liurl, listitem=listitem, 
						isFolder=True, totalItems=total)
	if page is not None: page = int(page) + 1
	else: page = 2
	if html.find('> >> <') > -1:
		AddOption('Next Page >>', True, 3000, section=section, genre=genre, letter=letter, sort=sort, page=page)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def TVShowSeasonList(url): #4000
	print 'Seasons for TV Show %s' % url
	html = GetURL(url)
	cnxn = sqlite.connect( DB )
	cursor = cnxn.cursor()
	regex = re.search('movie_thumb"><img src="(.+?)"', html)
	if regex: img = regex.group(1)
	else:
		ADDON.log_error('couldn\'t find image')
		img = ''

	seasons = re.search('tv_container(.+?)<div class="clearer', html, re.DOTALL)    
	if not seasons: ADDON.log_error('couldn\'t find seasons')
	else:
		for season in seasons.group(1).split('<h2>'):
			r = re.search('<a.+?>(.+?)</a>', season)
			if r:
				season_name = r.group(1)
				listitem = xbmcgui.ListItem(season_name, iconImage=img, thumbnailImage=img)
				season_name = unicode_urlencode(season_name).lower()
				#Disabled due to atv2/ipad storage server problem 
				#cache.set(season_name, season)
				cursor.execute('INSERT or REPLACE into seasons (season,contents) VALUES(?,?);',
								(season_name, season.decode("utf-8")))
				url = sys.argv[0]+'?mode=5000' + '&season=' + season_name + '&img=' + img
				xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, 
											isFolder=True)
				cnxn.commit()
			#else: print 'Couldn\'t determine season from match: %s' % r.group(1)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		cnxn.close()

def TVShowEpisodeList(season, img): #5000
	xbmcplugin.setContent( int( sys.argv[1] ), 'episodes' )
	#Disabled due to atv2/ipad storage server problem
	#eplist = cache.get(season)
	cnxn = sqlite.connect( DB )
	cursor = cnxn.cursor()
	eplist = cursor.execute('SELECT contents FROM seasons WHERE season=?', (season,))
	eplist = eplist.fetchone()[0]
	#print eplist
	r = '"tv_episode_item".+?href="(.+?)">(.*?)</a>'
	episodes = re.finditer(r, eplist, re.DOTALL)
	for ep in episodes:
		epurl, title = ep.groups()
		#print '%s @ %s' %(title, epurl)
		title = re.sub('<[^<]+?>', '', title.strip())
		title = re.sub('\s\s+' , ' ', title)
		title = urllib.unquote_plus(title)
		listitem = xbmcgui.ListItem(title, iconImage=img, thumbnailImage=img)
		url = '%s?mode=10&url=%s&title=%s&img=%s' % \
				(sys.argv[0], BASE_URL + epurl, unicode_urlencode(title), img)
		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, 
									isFolder=True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetParams():
	param=[]
	paramstring=sys.argv[len(sys.argv)-1]
	if len(paramstring)>=2:
		cleanedparams=paramstring.replace('?','')
		if (paramstring[len(paramstring)-1]=='/'):
				paramstring=paramstring[0:len(paramstring)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]			
	return param

print 'BEFORE GETPARAMS: %s' % sys.argv
params=GetParams()

try:	mode = 	  int(params['mode'])
except: mode =	  None
try:	section = params['section']
except: section = None
try: 	genre =   params['genre']
except: genre =   None
try:	letter =  params['letter']
except: letter =  None
try: 	sort =    params['sort']
except: sort =    None
try: 	url = 	  params['url']
except: url = 	  None
try: 	title =   params['title']
except: title =   None
try: 	img = 	  params['img']
except: img = 	  None
try: 	season =  params['season']
except: season =  None
try: 	query =  params['query']
except: query =  None
try: 	page =  params['page']
except: page =  None

print '==========================PARAMS:\nMODE: %s\nMYHANDLE: %s\nPARAMS: %s' % (mode, sys.argv[1], params )

initDatabase()

if mode==None: #Main menu
	AddonMenu()
elif mode==10: #Play Stream
	GetSources(url,title,img)
elif mode==500: #Browsing options menu
	BrowseListMenu(section)
elif mode==1000: #Browse by A-Z menu
	BrowseAlphabetMenu(section, genre)
elif mode==2000: #Browse by genre
	BrowseByGenreMenu(section)
elif mode==3000: #Show the results of the menus selected
	GetFilteredResults(section, genre, letter, sort, page)
elif mode==4000: #TV Show season list
	TVShowSeasonList(url)
elif mode==5000: #TVShow episode list
	TVShowEpisodeList(season, img)
elif mode==6000: #Get search terms
	GetSearchQuery(section)
elif mode==7000: #Get search results
	Search(section, query)
elif mode==9999: #Open URL Resolver Settings
	urlresolver.display_settings()