This is an XBMC script to view listings from on-my.tv.

It supports both filtered and unfiltered listings.  To enable this feature you must
visit http://on-my.tv/ and register.  You will be given a 32-character 'UID' which 
you must enter in the plugin cocnfiguration dialog.


