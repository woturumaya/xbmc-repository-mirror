# -*- coding: utf-8 -*-
# Copyright (c) 2010 Andre LeBlanc

import os
import xbmc
import xbmcgui
import xbmcaddon
__scriptname__ = "On-My.TV"
__author__ = "Andre LeBlanc <andrepleblanc@gmail.com>"
__url__ = "http://github.com/andrepl/"
__svn_url__ = ""
__credits__ = ""
__version__ = "0.0.1"
__XBMC_Revision__ = "30377"

BASE_RESOURCE_PATH = xbmc.translatePath( os.path.join( os.getcwd(), 'resources', 'lib' ) )
sys.path.append (BASE_RESOURCE_PATH)

__settings__ = xbmcaddon.Addon(id='script.onmytv')

__language__ = __settings__.getLocalizedString

KEY_BUTTON_BACK = 275
KEY_KEYBOARD_ESC = 61467

if __name__ == '__main__':
    from gui import TVListingGUI
    w = TVListingGUI("script-tvlisting-main.xml",os.getcwd() ,"Default")
    w.doModal()
    del w
