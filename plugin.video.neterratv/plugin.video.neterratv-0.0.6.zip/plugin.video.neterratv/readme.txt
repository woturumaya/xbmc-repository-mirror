Readme for XMBC neterratv plugin created mr.olix@gmail.com

I created this addon to watch NeterraTV on my jailbreak AppleTV 2. 
Before I used to stream from my IPad via Airplay but the quality was that good I always had to fight
with my daughter over IPad. I have also tested the on my Win7 machine. I didn't test on any other hardware.

Note: The plugin uses methods from module script.module.beautifulsoup. This should be installed
automatically when you install from zip file. If not install the MyVideo.de plugin from Tristan 
Fischer which is available in the official XBMC addon repositiory. 