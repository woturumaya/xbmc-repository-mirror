plugin.video.neterratv
=====================

XBMC plugin for neterra TV. Bulgaria TV internet provider