import xbmc

xbmc.executebuiltin('RunScript(script.libraryautoupdate)')
