xbmc.mp3search
==============

another xbmc audio plugin 