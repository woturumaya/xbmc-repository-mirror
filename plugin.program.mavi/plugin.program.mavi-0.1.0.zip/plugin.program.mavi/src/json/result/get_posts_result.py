class GetPostsResult:
    modHash = None
    data = list()
    after = None
    before = None
    
    def isValid(self):
#        TODO
        return