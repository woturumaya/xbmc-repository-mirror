'''
Created on 13 jun 2011

@author: Nick
'''
class RedditComment:
    body = None
    subreddit_id = None
    name = None
    author = None
    downs = None
    created = None
    created_utc = None
    body_html = None
    levenshtein = None
    link_id = None
    parent_id = None
    likes = None
    replies = list()
    id = None
    subreddit = None
    ups = None