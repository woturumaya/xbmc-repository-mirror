import sys
epgService      = '/ds/epg/service.asmx'
server          = 'ivsmedia.iptv-distribution.net'
MediaService    = '/MediaService.svc/soap'
ContentService  = '/ContentService.svc/soap'
ClientService   = '/ClientService.svc/soap'
siteId          = '2'
appName         = 'XBMC Plugin (' + sys.platform + ')'
streamService   = '/ds/cas/streams/generic/stream.asmx'
protocol        = 'mms'
vodService      = '/ucas/service.asmx'
vod2Service     = '/ds/vod/generic/service.asmx'
radioService    = '/ucas/service.asmx'


