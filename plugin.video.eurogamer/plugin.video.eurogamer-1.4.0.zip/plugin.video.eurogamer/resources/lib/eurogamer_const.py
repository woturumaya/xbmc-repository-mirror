import xbmcaddon

#
# Constants
# 
__settings__ = xbmcaddon.Addon(id='plugin.video.eurogamer')
__language__ = __settings__.getLocalizedString
