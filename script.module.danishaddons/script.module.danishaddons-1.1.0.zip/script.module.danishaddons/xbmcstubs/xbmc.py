__author__ = 'twi'

textValue = None

def translatePath(path):
    return path

class Keyboard:
    def __init__(self, text, title):
        pass

    def doModal(self):
        pass

    def isConfirmed(self):
        return True

    def getText(self):
        return textValue