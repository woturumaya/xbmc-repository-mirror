A Simple addon to aggregate and stream content from various combat sport related content sources.

Currently Supported Feeds:

Video:

    # Bellator MMA (Youtube)
    # Budovideos Online: Jiu-Jitsu, Grappling, MMA (RSS)
    # Eddie Bravo (Youtube)
    # Evolve Mixed Martial Arts (Youtube)
    # HDNet Fights (Youtube)
    # Iron Forges Iron (Youtube)
    # MMA H.E.A.T. (Youtube)
    # MMA Nuts (RSS)
    # MMA: Inside the Cage (Youtube)
    # MMAFighting.com (Plugin)
    # MMAWeekly.com Videos (Youtube)
    # MMAinterviews.tv (Youtube)
    # Middleeasy TV (Youtube)
    # NickTheFace MMA Promos (Youtube)
    # StillW1ll (Youtube)
    # The Best of the UFC (RSS)
    # The Fight Nerd (Youtube)
    # The Fight Network (Youtube)
    # The Reem (Vimeo)
    # UFC (Youtube)
    # WHOA! TV (Youtube)
    # www.MMA30.com (Youtube)

Audio:

    # BTR: MMA Scraps Radio (RSS)
    # BTR: MMASweetDown (RSS)
    # Bloody Elbow Radio (RSS)
    # ESPN: Gross Point Blank MMA Podcast (RSS)
    # ESPN: UFC Podcast (RSS)
    # FightFans Radio Presents (RSS)
    # IT'S TIME!!! With Bruce Buffer (RSS)
    # Joe Show Radio - Underground MMA Radio (RSS)
    # MMA Radio: Beatdown with TJ De Santis (RSS)
    # MMA Sunday School with Scott Holmes and Rodney Dean (RSS)
    # MMAjunkie.com Radio (RSS)
    # Sherdog Radio Network: Rewind (RSS)
    # TapouT Radio (RSS)
    # The Bum Rush Radio Show (RSS)
    # The Joe Rogan Experience (RSS)
    # The Jordan Breen Show on the Sherdog Radio Network (RSS)
    # The MMA Hour - Audio (RSS)
    # The Savage Dog Show with Greg Savage and Jeff Sherwood (RSS)
