import os

mkdir = os.mkdir
