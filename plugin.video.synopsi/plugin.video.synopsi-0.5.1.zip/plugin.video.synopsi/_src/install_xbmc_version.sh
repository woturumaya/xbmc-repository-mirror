sudo aptitude install xbmc=2:11.0~git20120423.cd20772-1
