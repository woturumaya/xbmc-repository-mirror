import xbmcgui

xbmcgui.Dialog().ok('Si ok ? spustil si service', 'Toto mal byt nadpis')

