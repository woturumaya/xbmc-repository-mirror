The Joe Rogan Experience Video Plugin for XBMC
=======================

This plugin will allow you to browse and stream video episodes of the Joe Rogan Experience podcast.

This repo contains the Eden fork of this addon, if you are running Dharma please see: https://github.com/lextoumbourou/xbmc-joe-rogan-experience

If you have any questions or comments please post in the addon thread on the XBMC forum: http://forum.xbmc.org/showthread.php?t=111254

Or you can of course add an issue on Github.
