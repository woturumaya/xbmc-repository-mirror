"""Support data for the musicbrainz2 package.

This package is I{not} part of the public API, it has been added to work
around shortcomings in python and may thus be removed at any time.

Please use the L{musicbrainz2.utils} module instead.
"""
__revision__ = '$Id: __init__.py 7386 2006-04-30 11:12:55Z matt $'

# EOF
