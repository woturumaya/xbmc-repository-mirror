vgtv-xbmc
=========

XBMC plugin for browsing and playing videos from VGTV.no