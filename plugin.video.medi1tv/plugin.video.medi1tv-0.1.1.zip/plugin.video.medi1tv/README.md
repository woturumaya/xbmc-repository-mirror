Medi1TV Addon for XBMC
========================
version 0.0.1

### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that allows you to watch videos from <http://www.medi1tv.com/ar>.

### Setup/Installation ###
The plugin should be available in the official XBMC addon repository. You can
install it within XBMC.

Contact: <ayoubuto@gmail.com> or [Apolikamixitos](http://forum.xbmc.org/member.php?u=123918) on <http://forum.xbmc.org>.
