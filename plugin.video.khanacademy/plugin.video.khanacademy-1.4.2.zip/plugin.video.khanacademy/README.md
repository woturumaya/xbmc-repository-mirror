Khan Academey for XBMC
=======================
version 1.4.1

### Summary

Watch lectures from [Khan Academcy](http://www.khanacademy.org) within 
the [XBMC](http://xbmc.org).

### Features

* Browse courses and lessons found on the website.

### Setup/Installation

If you are using XBMC Dharma and above, you should be able to install
this plugin through the official addons installer within XBMC. 

If you are using an XBMC version before Dharma, check out the  
[XBMC wiki](http://wiki.xbmc.org/?title=HOW-TO_install_and_use_plugins_in_XBMC)
for installation instructions.

### To Do

* Add search support.

### Contact

xbmc@jonathanbeluch.com  
jbel on [http://forum.xbmc.org](http://forum.xbmc.org)
