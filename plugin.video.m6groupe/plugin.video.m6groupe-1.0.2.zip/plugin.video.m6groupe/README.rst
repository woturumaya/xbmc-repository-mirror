=====================
plugin.video.m6groupe
=====================

XBMC addon to watch videos from french channels M6 and W9
