This script can automaticly update your movies/tvshows in your library.

XBMC 12.0 Frodo ONLY