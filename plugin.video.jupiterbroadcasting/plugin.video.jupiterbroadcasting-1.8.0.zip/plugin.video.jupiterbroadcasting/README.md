Jupiter Broadcasting XBMC Addon
===============================
Watch shows from the [Jupiter Broadcasting](http://jupiterbroadcasting.com) network in [XBMC](http://xbmc.org/).

Shows
-----
* [Live Show](http://jblive.tv)
* Linux Action Show
* TechSNAP
* STOked
* TORked
* SciByte
* In Depth Look
* FauxShow
* Jupiter@Nite
* The MMOrgue
* LOTSO
* Unfilter
* Coder Radio
* Beer Is Tasty
* Jupiter Files

Instructions
------------
1. Download the addon from the official XBMC Addon Repository
2. Visit Video Addons, configure and load up Jupiter Broadcasting

